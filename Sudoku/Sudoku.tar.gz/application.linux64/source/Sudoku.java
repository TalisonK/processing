import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Sudoku extends PApplet {

public void setup() {
  PFont f;
  // Create the font
  f = createFont("DejaVu Sans", 40);
  textFont(f);
  textAlign(CENTER, CENTER);
  
}

Logic l = new Logic();


int casay = 0;
int casax = 0;

public void draw() {

  background(255);

  //quadrados do jogo
  translate(2, 2);
  noFill();
  stroke(0);
  strokeWeight(1);
  for (int j = 0; j < 9; j++) {
    for (int i = 0; i < 9; i++) {
      square(i*60, j*60, 60);
    }
  }
  strokeWeight(3);
  noFill();
  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      square(j*180, i*180, 180);
    }
  }

  //numeros
  translate(0, 0);

  for (int j = 0; j < 9; j++) {
    for (int i = 0; i < 9; i++) {
      fill(0);
      text(l.plano.get(j).get(i), i*60 + 30, j*60+30);
    }
  }



  //seleçao
  translate(0, 0);
  noFill();
  stroke(255, 0, 0);
  square(casay + 3, casax + 3, 55);
  //println(casax/60, casay/60);
}

public void keyPressed()
{
  if (key >= PApplet.parseChar(49) && key <= PApplet.parseChar(49+9)) {
    l.addnum(key-48,casax/60,casay/60);
  } else {
    if (keyCode == UP || key == 'w') {
      if (casax >= 60) casax -= 60;
    } else if (keyCode == LEFT || key == 'a') {
      if (casay >= 60) casay -= 60;
    } else if (keyCode == RIGHT || key == 'd') {
      if (casay < 480) casay += 60;
    } else if (keyCode == DOWN || key == 's') {
      if (casax < 480) casax += 60;
    }
  }
}


public class Logic {

  public ArrayList<ArrayList<Integer>> plano;
  private int dificuldade;

  public Logic() {
    this.dificuldade = 50;  //Dificuldade do jogo
    plano = new ArrayList();
    Random r = new Random();
    for (int i = 0; i < 9; i++) {
      plano.add(new ArrayList<Integer>(Arrays.asList(0, 0, 0, 0, 0, 0, 0, 0, 0)));
    }
    
    for (int i = 0; i < 9; i ++) {
      for (int j = 0; j < 9; j++) {
        int aux= r.nextInt(100);
        
        if(aux < dificuldade) this.addnum(r.nextInt(9)+1, i, j);
        
      }
    }
  }


  public boolean addnum(int num, int casax, int casay) {
    if (confere_quadro(num, casax, casay) && confere_linha(num, casax) && confere_coluna(num, casay)) {
      plano.get(casax).add(casay, num);
      plano.get(casax).remove(casay + 1);
      return true;
    }
    return false;
  }

  private boolean confere_quadro(int num, int casax, int casay) {
    int indl = casax / 3;
    int indc = casay / 3;
    boolean cond = true;
    for (int i = indl * 3; i < indl * 3 + 3; i++) {
      for (int j = indc * 3; j < indc* 3 + 3; j++) {
        if (this.plano.get(i).get(j) == num)
        {
          cond = false;
          break;
        }
        if (!cond) break;
      }
    }
    return cond;
  }

  private boolean confere_coluna(int num, int casay) {
    for (int i = 0; i < 9; i++) {
      if (plano.get(i).get(casay) == num) return false;
    }
    return true;
  }

  private boolean confere_linha(int num, int casax) {
    for (Integer i : plano.get(casax)) {
      if (num == i) return false;
    }
    return true;
  }


  @Override
    public String toString() {
    String r = "";
    for (ArrayList<Integer> i : plano) {
      r += i.toString() + "\n";
    }
    return r;
  }
}






//for (int i = 0; i < 9; i++){
//    noFill();
//    translate(0,0);
//    square(i*60, height - 75, 60);
//    fill(0);
//    text(char(i+49), i*60 + 30, height -50);
//}
  public void settings() {  size(550, 560); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Sudoku" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
